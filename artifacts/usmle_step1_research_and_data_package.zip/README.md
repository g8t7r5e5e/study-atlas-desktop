# Study Atlas Checkpoint 1 package

Start with docs/data/CHECKPOINT1.md and docs/data/README.md.
This shareable package contains reusable import code, SQL schema, verification
reports, source/rights manifests and 22 referenced official category records.
It does NOT contain the private question/video/index catalogs, mapping candidates,
question bodies, Anki content, student records or the owner's prototype snapshot.
The real normalized database and CSV/JSON exports were built separately in the
private local workspace. See the aggregate report for actual counts and gaps.
Test fixtures inside test source are synthetic tests, never research datasets.
No installer, complete planner UI, or clinical validation is claimed.

From desktop/: python -m unittest discover -s data_foundation/tests -v
Verify ZIP: python -m data_foundation.package --verify /path/to/package.zip
